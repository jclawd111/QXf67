//! Protocol 3 draft implementation: recovery authority and delayed withdrawals.
//! NOT deployed, NOT audited, NOT enabled anywhere. Specification and open
//! questions: docs/PROTOCOL.md. Signatures are LM-OTS (RFC 8554), verified by
//! `crates/qsafe-lmots`.
pub mod state;
use solana_account_info::{next_account_info, AccountInfo};
use solana_clock::Clock;
use solana_cpi::{invoke, invoke_signed};
use solana_program_entrypoint::ProgramResult;
use solana_program_error::ProgramError;
use solana_program_pack::Pack;
use solana_pubkey::Pubkey;
use solana_rent::Rent;
use solana_sha256_hasher::hashv;
use solana_system_interface::{instruction as system_instruction, program as system_program};
use solana_sysvar::Sysvar;
use state::*;
use qsafe_lmots::{candidate_key, IDENTIFIER_LEN};
#[cfg(not(feature = "no-entrypoint"))]
solana_program_entrypoint::entrypoint!(process_instruction);

pub const SIGNATURE_LEN: usize = qsafe_lmots::SIGNATURE_LEN;
pub const PROOF_LEN: usize = 74 + SIGNATURE_LEN;
/// The most chain steps a signature may take to verify: 255 * 16. The count
/// for a message digest whose checksum has high byte `h` is always
/// 255 * (h + 2), so this admits `h <= 14`. A signer meets it by its choice of
/// randomizer, a little over one try in four. It bounds what `announce` and
/// `recover` can cost, whatever the message.
pub const VERIFY_STEP_LIMIT: u32 = 4080;
const IDENTIFIER_DOMAIN: &[u8; 16] = b"QSAFE_3_LMOTS_ID";

/// The LM-OTS identifier `I` of the key at one position: a role, an epoch and
/// an operation index (zero for recovery) under one program, chain and vault
/// salt. Every hash a signature involves starts with it, so a signature made
/// for one position verifies at no other. `q` is always zero, as RFC 8554
/// section 4 requires of LM-OTS used outside an LMS tree.
///
/// The salt is public once a vault exists, so someone can create another vault
/// whose keys share these identifiers. That gives them nothing against this
/// vault: their keys are their own, and every signed message names its vault.
fn identifier(id: &Pubkey, v: &Vault, role: u8, epoch: u64, index: u64) -> [u8; IDENTIFIER_LEN] {
    let h = hashv(&[
        IDENTIFIER_DOMAIN,
        id.as_ref(),
        &v.chain_tag,
        &v.salt,
        &[role],
        &epoch.to_le_bytes(),
        &index.to_le_bytes(),
    ])
    .to_bytes();
    h[..IDENTIFIER_LEN].try_into().unwrap()
}
const PROOF_MAGIC: &[u8; 8] = b"QSPROOF3";
const SPENT_MAGIC: &[u8; 8] = b"QSSPENT3";
const VAULT_SEED: &[u8] = b"qsafe3";
const PROOF_SEED: &[u8] = b"proof";
const SPENT_SEED: &[u8] = b"spent-v3";
/// The associated token account program. A wallet's token account for a mint
/// has an address anyone can compute, and nobody else can occupy it.
const ASSOCIATED_TOKEN_PROGRAM: Pubkey =
    solana_pubkey::pubkey!("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL");

/// Whether an announced destination belongs to one of the vault's trusted
/// wallets: for SOL the wallet itself, for a token that wallet's associated
/// token account for the mint.
fn to_trusted(v: &Vault, a: &Announce) -> bool {
    if a.kind == 0 {
        return v.trusts(&a.destination);
    }
    v.trusted.iter().filter(|w| **w != [0; 32]).any(|wallet| {
        Pubkey::find_program_address(
            &[wallet, spl_token::id().as_ref(), &a.mint],
            &ASSOCIATED_TOKEN_PROGRAM,
        )
        .0
        .to_bytes()
            == a.destination
    })
}

fn owned(a: &AccountInfo, id: &Pubkey, len: usize, magic: &[u8; 8]) -> ProgramResult {
    require(a.owner == id && a.data_len() == len)?;
    require(&a.try_borrow_data()?[..8] == magic)
}
/// The marker for `root` in this vault must not exist yet. Returns its bump.
/// Markers are scoped to one vault: nothing done to any other vault can create
/// or occupy them.
fn unspent(
    id: &Pubkey,
    vault: &Pubkey,
    account: &AccountInfo,
    root: &[u8; 32],
) -> Result<u8, ProgramError> {
    let (expected, bump) =
        Pubkey::find_program_address(&[SPENT_SEED, vault.as_ref(), root], id);
    require(account.key == &expected)?;
    // A marker that exists means this root has already signed.
    need(
        account.owner == &system_program::id() && account.data_is_empty(),
        Refusal::NextRootUnusable,
    )?;
    Ok(bump)
}
fn create<'a>(
    payer: &AccountInfo<'a>,
    account: &AccountInfo<'a>,
    system: &AccountInfo<'a>,
    id: &Pubkey,
    len: usize,
    seeds: &[&[u8]],
) -> ProgramResult {
    require(
        payer.is_signer
            && payer.is_writable
            && account.is_writable
            && system.key == &system_program::id(),
    )?;
    // A prefunded PDA must not be a permanent denial of service.
    require(account.owner == &system_program::id() && account.data_is_empty())?;
    let needed = Rent::get()?
        .minimum_balance(len)
        .saturating_sub(account.lamports());
    if needed > 0 {
        invoke(
            &system_instruction::transfer(payer.key, account.key, needed),
            &[payer.clone(), account.clone(), system.clone()],
        )?;
    }
    invoke_signed(
        &system_instruction::allocate(account.key, len as u64),
        &[account.clone(), system.clone()],
        &[seeds],
    )?;
    invoke_signed(
        &system_instruction::assign(account.key, id),
        &[account.clone(), system.clone()],
        &[seeds],
    )
}
/// Permanently marks `root` as used, in either role, for this vault.
fn mark_spent<'a>(
    payer: &AccountInfo<'a>,
    marker: &AccountInfo<'a>,
    system: &AccountInfo<'a>,
    id: &Pubkey,
    vault: &Pubkey,
    root: &[u8; 32],
) -> ProgramResult {
    let bump = unspent(id, vault, marker, root)?;
    create(
        payer,
        marker,
        system,
        id,
        SPENT_MAGIC.len(),
        &[SPENT_SEED, vault.as_ref(), root, &[bump]],
    )?;
    marker.try_borrow_mut_data()?.copy_from_slice(SPENT_MAGIC);
    Ok(())
}
/// Loads a vault and proves the account is the PDA of its own stored identity.
fn load_vault(id: &Pubkey, vault: &AccountInfo) -> Result<Vault, ProgramError> {
    require(vault.owner == id && vault.is_writable)?;
    let v = Vault::unpack(&vault.try_borrow_data()?)?;
    require(
        Pubkey::create_program_address(&[VAULT_SEED, &v.vault_id, &[v.bump]], id)
            .map_err(|_| invalid())?
            == *vault.key,
    )?;
    Ok(v)
}
fn store_vault(vault: &AccountInfo, v: &Vault) -> ProgramResult {
    v.pack(&mut vault.try_borrow_mut_data()?)
}
/// Checks the staged proof is complete and is for exactly this message, then
/// verifies it against `root`.
#[inline(never)]
fn verify_proof(
    id: &Pubkey,
    proof: &AccountInfo,
    message: [&[u8]; 4],
    digest: &[u8; 32],
    root: &[u8; 32],
    identifier: &[u8; IDENTIFIER_LEN],
) -> ProgramResult {
    owned(proof, id, PROOF_LEN, PROOF_MAGIC)?;
    let d = proof.try_borrow_data()?;
    need(
        u16::from_le_bytes(d[72..74].try_into().unwrap()) as usize == SIGNATURE_LEN
            && d[40..72] == *digest,
        Refusal::ProofNotReady,
    )?;
    // The candidate key is computed from the signature; the signature is good
    // only if that is the key the vault holds.
    match candidate_key(identifier, 0, message, &d[74..], VERIFY_STEP_LIMIT) {
        Some(candidate) if candidate == *root => Ok(()),
        _ => Err(ProgramError::MissingRequiredSignature),
    }
}

pub fn process_instruction(id: &Pubkey, accounts: &[AccountInfo], input: &[u8]) -> ProgramResult {
    let (op, data) = input.split_first().ok_or_else(invalid)?;
    match op {
        0 => initialize(id, accounts, data),
        1 => stage(id, accounts, data),
        2 => announce(id, accounts, data),
        3 => execute(id, accounts, data),
        4 => expire(id, accounts, data),
        5 => recover(id, accounts, data),
        6 => close_proof(id, accounts, data),
        _ => Err(invalid()),
    }
}

fn initialize(id: &Pubkey, accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
    require(accounts.len() == 3 && data.len() == INIT_LEN)?;
    let it = &mut accounts.iter();
    let payer = next_account_info(it)?;
    let vault = next_account_info(it)?;
    let system = next_account_info(it)?;
    // The address commits to every creation parameter, so whoever creates the
    // account first can only create exactly the vault its owner derived.
    let vault_id = hashv(&[VAULT_ID_DOMAIN, data]).to_bytes();
    let (expected, bump) = Pubkey::find_program_address(&[VAULT_SEED, &vault_id], id);
    need(vault.key == &expected, Refusal::WrongVaultAddress)?;
    let v = new_vault(vault_id, data, bump)?;
    create(
        payer,
        vault,
        system,
        id,
        VAULT_LEN,
        &[VAULT_SEED, &v.vault_id, &[bump]],
    )?;
    store_vault(vault, &v)
}

fn stage(id: &Pubkey, accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
    require(accounts.len() == 3 && data.len() > 34 && data.len() <= 634)?;
    let digest = &data[..32];
    let offset = u16::from_le_bytes(data[32..34].try_into().unwrap()) as usize;
    let chunk = &data[34..];
    require(offset.checked_add(chunk.len()).ok_or_else(invalid)? <= SIGNATURE_LEN)?;
    let it = &mut accounts.iter();
    let payer = next_account_info(it)?;
    let proof = next_account_info(it)?;
    let system = next_account_info(it)?;
    require(payer.is_signer && proof.is_writable && system.key == &system_program::id())?;
    let (expected, bump) =
        Pubkey::find_program_address(&[PROOF_SEED, payer.key.as_ref(), digest], id);
    require(proof.key == &expected)?;
    if proof.data_is_empty() {
        require(offset == 0)?;
        create(
            payer,
            proof,
            system,
            id,
            PROOF_LEN,
            &[PROOF_SEED, payer.key.as_ref(), digest, &[bump]],
        )?;
        let mut d = proof.try_borrow_mut_data()?;
        d[..8].copy_from_slice(PROOF_MAGIC);
        d[8..40].copy_from_slice(payer.key.as_ref());
        d[40..72].copy_from_slice(digest);
    }
    owned(proof, id, PROOF_LEN, PROOF_MAGIC)?;
    let mut d = proof.try_borrow_mut_data()?;
    require(&d[8..40] == payer.key.as_ref() && &d[40..72] == digest)?;
    let used = u16::from_le_bytes(d[72..74].try_into().unwrap()) as usize;
    // Safe retry: identical previously appended chunks may be submitted again.
    if offset < used {
        return require(
            offset + chunk.len() <= used && &d[74 + offset..74 + offset + chunk.len()] == chunk,
        );
    }
    require(offset == used)?;
    d[74 + offset..74 + offset + chunk.len()].copy_from_slice(chunk);
    d[72..74].copy_from_slice(&((used + chunk.len()) as u16).to_le_bytes());
    Ok(())
}

/// Verifies an operational signature, rotates that authority and records the
/// withdrawal. Moves no assets.
fn announce(id: &Pubkey, accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
    let a = decode_announce(data)?;
    // A token withdrawal also names its mint, so the mint can be checked now
    // rather than discovered to be unusable when the withdrawal is released,
    // and a token account of the vault's that holds the amount.
    require(accounts.len() == if a.kind == 1 { 8 } else { 6 })?;
    let it = &mut accounts.iter();
    let vault = next_account_info(it)?;
    let proof = next_account_info(it)?;
    let payer = next_account_info(it)?;
    let spent = next_account_info(it)?;
    let next_spent = next_account_info(it)?;
    let system = next_account_info(it)?;
    let mut source = None;
    if a.kind == 1 {
        let mint = next_account_info(it)?;
        // A classic mint can never be closed or change owner, so what is
        // checked here still holds at execution.
        require(mint.key.to_bytes() == a.mint)?;
        need(mint.owner == &spl_token::id(), Refusal::MintNotSupported)?;
        let m = spl_token::state::Mint::unpack(&mint.try_borrow_data()?)
            .map_err(|_| Refusal::MintNotSupported)?;
        need(m.decimals == a.decimals, Refusal::WrongDecimals)?;
        source = Some(next_account_info(it)?);
    }
    let mut v = load_vault(id, vault)?;
    // The vault must be able to pay what is announced, by the same rules
    // `execute` applies. A record it could not pay would hold the one pending
    // slot until it expired. Nothing but `execute` takes from a vault, and
    // `execute` needs this record, so what can be paid now can be paid then.
    // (A token's issuer can still freeze the vault's account in between;
    // that is outside the vault's control.)
    match source {
        None => {
            let reserve = Rent::get()?.minimum_balance(VAULT_LEN);
            need(
                vault.lamports().checked_sub(a.amount).is_some_and(|left| left >= reserve),
                Refusal::NotPayable,
            )?;
        }
        Some(source) => {
            need(source.owner == &spl_token::id(), Refusal::NotPayable)?;
            let s = spl_token::state::Account::unpack(&source.try_borrow_data()?)
                .map_err(|_| Refusal::NotPayable)?;
            need(
                s.owner == *vault.key
                    && s.mint.to_bytes() == a.mint
                    && s.delegate.is_none()
                    && s.close_authority.is_none()
                    && !s.is_frozen()
                    && s.amount >= a.amount,
                Refusal::NotPayable,
            )?;
        }
    }
    for reserved in [vault.key, proof.key, spent.key, next_spent.key] {
        need(a.destination != reserved.to_bytes(), Refusal::DestinationNotAllowed)?;
    }
    unspent(id, vault.key, next_spent, &a.next_op_root)?;
    let message: [&[u8]; 4] = [ANNOUNCE_DOMAIN, id.as_ref(), vault.key.as_ref(), data];
    let digest = hashv(&message).to_bytes();
    // The key is named by the vault's epoch and the index being used up.
    let signer = identifier(id, &v, ROLE_OPERATIONAL, v.epoch, v.op_index);
    // Cheap state checks first; `displaced` is the root the signature must match.
    let trusted = to_trusted(&v, &a);
    let displaced = apply_announce(&mut v, &a, digest, Clock::get()?.unix_timestamp, trusted)?;
    verify_proof(id, proof, message, &digest, &displaced, &signer)?;
    mark_spent(payer, spent, system, id, vault.key, &displaced)?;
    store_vault(vault, &v)
}

/// Carries out the recorded withdrawal inside its window. Takes no data: every
/// transfer field comes from the record. Permissionless.
fn execute(id: &Pubkey, accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
    require(data.is_empty() && accounts.len() >= 2)?;
    let it = &mut accounts.iter();
    let vault = next_account_info(it)?;
    let destination = next_account_info(it)?;
    let mut v = load_vault(id, vault)?;
    let p = check_execute(&v, Clock::get()?.unix_timestamp)?;
    need(
        destination.key.to_bytes() == p.destination && destination.key != vault.key,
        Refusal::WrongDestination,
    )?;
    require(destination.is_writable)?;
    if p.kind == 0 {
        require(accounts.len() == 2)?;
        let remaining = vault
            .lamports()
            .checked_sub(p.amount)
            .ok_or(ProgramError::InsufficientFunds)?;
        need(
            remaining >= Rent::get()?.minimum_balance(VAULT_LEN),
            Refusal::BelowRentReserve,
        )?;
        let received = destination
            .lamports()
            .checked_add(p.amount)
            .ok_or(ProgramError::ArithmeticOverflow)?;
        **vault.try_borrow_mut_lamports()? = remaining;
        **destination.try_borrow_mut_lamports()? = received;
    } else {
        require(accounts.len() == 5)?;
        let source = next_account_info(it)?;
        let mint_account = next_account_info(it)?;
        let token = next_account_info(it)?;
        let mint = Pubkey::new_from_array(p.mint);
        need(
            token.key == &spl_token::id()
                && mint_account.key == &mint
                && mint_account.owner == &spl_token::id()
                && source.owner == &spl_token::id()
                && destination.owner == &spl_token::id()
                && source.is_writable
                && source.key != destination.key,
            Refusal::WrongTokenAccounts,
        )?;
        let wrong = |_| ProgramError::from(Refusal::WrongTokenAccounts);
        let src = spl_token::state::Account::unpack(&source.try_borrow_data()?).map_err(wrong)?;
        let dst =
            spl_token::state::Account::unpack(&destination.try_borrow_data()?).map_err(wrong)?;
        let m = spl_token::state::Mint::unpack(&mint_account.try_borrow_data()?).map_err(wrong)?;
        need(
            src.owner == *vault.key
                && src.mint == mint
                && dst.mint == mint
                && src.delegate.is_none()
                && src.close_authority.is_none(),
            Refusal::WrongTokenAccounts,
        )?;
        invoke_signed(
            &spl_token::instruction::transfer_checked(
                &spl_token::id(),
                source.key,
                &mint,
                destination.key,
                vault.key,
                &[],
                p.amount,
                m.decimals,
            )?,
            &[
                source.clone(),
                mint_account.clone(),
                destination.clone(),
                vault.clone(),
                token.clone(),
            ],
            &[&[VAULT_SEED, &v.vault_id, &[v.bump]]],
        )?;
    }
    // Cleared in the same instruction as the transfer: at most one execution.
    v.pending = None;
    store_vault(vault, &v)
}

/// Clears a record past its deadline. Moves nothing. Permissionless.
fn expire(id: &Pubkey, accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
    require(data.is_empty() && accounts.len() == 1)?;
    let vault = &accounts[0];
    let mut v = load_vault(id, vault)?;
    apply_expire(&mut v, Clock::get()?.unix_timestamp)?;
    store_vault(vault, &v)
}

/// Verifies the fixed recovery packet for the current epoch and installs the
/// next epoch's authorities. Clears any pending withdrawal. Never debits the vault.
fn recover(id: &Pubkey, accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
    let r = decode_recover(data)?;
    require(accounts.len() == 7)?;
    let it = &mut accounts.iter();
    let vault = next_account_info(it)?;
    let proof = next_account_info(it)?;
    let payer = next_account_info(it)?;
    let rec_spent = next_account_info(it)?;
    let next_rec_spent = next_account_info(it)?;
    let next_op_spent = next_account_info(it)?;
    let system = next_account_info(it)?;
    let mut v = load_vault(id, vault)?;
    unspent(id, vault.key, next_rec_spent, &r.next_rec_root)?;
    unspent(id, vault.key, next_op_spent, &r.next_op_root)?;
    let message: [&[u8]; 4] = [RECOVER_DOMAIN, id.as_ref(), vault.key.as_ref(), data];
    let digest = hashv(&message).to_bytes();
    // The recovery key of the epoch being left. There is one per epoch.
    let signer = identifier(id, &v, ROLE_RECOVERY, v.epoch, 0);
    let old_rec = apply_recover(&mut v, &r)?;
    verify_proof(id, proof, message, &digest, &old_rec, &signer)?;
    // Only a root that has signed is ever marked. The displaced operational
    // root has not signed here and is left alone (see `apply_recover`).
    mark_spent(payer, rec_spent, system, id, vault.key, &old_rec)?;
    store_vault(vault, &v)
}

fn close_proof(id: &Pubkey, accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
    require(accounts.len() == 2 && data.is_empty())?;
    let it = &mut accounts.iter();
    let proof = next_account_info(it)?;
    let payer = next_account_info(it)?;
    owned(proof, id, PROOF_LEN, PROOF_MAGIC)?;
    require(
        payer.is_signer
            && payer.is_writable
            && proof.is_writable
            && payer.key != proof.key
            && &proof.try_borrow_data()?[8..40] == payer.key.as_ref(),
    )?;
    let total = payer
        .lamports()
        .checked_add(proof.lamports())
        .ok_or(ProgramError::ArithmeticOverflow)?;
    **payer.try_borrow_mut_lamports()? = total;
    **proof.try_borrow_mut_lamports()? = 0;
    proof.try_borrow_mut_data()?.fill(0);
    // Hand the address back to the system program so it can be staged again
    // even if something refunds it within this transaction.
    proof.resize(0)?;
    proof.assign(&system_program::id());
    Ok(())
}
